---
layout: theme
title: Eternal
category: theme
homepage: https://decade.net.cn
download: https://github.com/Decade-qiu/Typora-theme-Eternal
author: decade
thumbnail: Eternal.png
typora-root-url: ../../
typora-copy-images-to: ../../media/theme/Eternal
---

>此主题仅在Windows下设计和测试，在其他操作系统上的效果未知！

>欢迎来访我的博客：[decade](https://decade.net.cn), 与该主题风格类似(主打一个简洁，清爽)。

# Eternal

![https://github.com/Decade-qiu/theme.typora.io/assets/74434779/2fea9187-d102-4986-bd85-65bffb9d71b3](https://github.com/Decade-qiu/theme.typora.io/blob/gh-pages/media/thumbnails/Eternal.png)

